import React from 'react';

export default function CategoryModal({
    showCategoryModal,
    setShowCategoryModal,
    categoryList,
    filters,
    handleCategoryBrand,
}) {
    if (!showCategoryModal) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-sm transition-opacity">
            <div className="bg-white dark:bg-gray-800 rounded-[2rem] w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-fade-in-up border border-gray-100 dark:border-gray-700">
                <div className="p-4 sm:p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-800/50 relative">
                    <div className="flex items-center gap-3 sm:gap-4">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-100 dark:bg-orange-900/30 text-orange-500 rounded-full flex items-center justify-center shadow-inner">
                            <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                        </div>
                        <div>
                            <h3 className="text-lg sm:text-2xl font-black text-gray-900 dark:text-white tracking-tight">Semua Kategori Premium</h3>
                            <p className="text-[11px] sm:text-xs text-gray-500 dark:text-gray-300 mt-0.5">Pilih brand untuk melihat daftar produk.</p>
                        </div>
                    </div>
                    <button onClick={() => setShowCategoryModal(false)} className="p-2.5 text-gray-400 hover:text-white bg-gray-100 hover:bg-red-500 dark:bg-gray-700 dark:hover:bg-red-500 transition-colors rounded-full cursor-pointer shadow-sm absolute top-4 right-4 sm:top-6 sm:right-6" aria-label="Tutup Modal Kategori">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-gray-50/50 dark:bg-gray-900/50">
                    {categoryList.length === 0 ? (
                        <div className="text-center text-gray-500 py-10 font-bold">Kategori belum tersedia.</div>
                    ) : (
                        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4 sm:gap-6 pt-2">
                            <div onClick={() => handleCategoryBrand('')} className="flex flex-col items-center gap-2 cursor-pointer group">
                                <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center border-2 transition-all shadow-sm ${!filters.category ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/30 text-orange-500' : 'border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-400 group-hover:border-orange-200'}`}>
                                    <svg className="w-6 h-6 sm:w-8 sm:h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                                </div>
                                <span className={`text-[11px] sm:text-xs font-bold text-center leading-tight line-clamp-2 ${!filters.category ? 'text-orange-500' : 'text-gray-600 dark:text-gray-300'}`}>Semua<br/>Brand</span>
                            </div>

                            {categoryList.map((cat, index) => (
                                <div key={index} onClick={() => handleCategoryBrand(cat.name)} className="flex flex-col items-center gap-2 cursor-pointer group">
                                    <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden flex items-center justify-center border-2 transition-all p-1 shadow-sm ${filters.category === cat.name ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/30' : 'border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800 group-hover:border-orange-200'}`}>
                                        {cat.image ? (
                                            <img src={cat.image} alt={cat.name} className="w-full h-full object-cover rounded-xl" />
                                        ) : (
                                            <div className="w-full h-full bg-gray-200 dark:bg-gray-600 rounded-xl flex items-center justify-center font-black text-gray-400 text-xs">PK</div>
                                        )}
                                    </div>
                                    <span className={`text-[11px] sm:text-xs font-bold text-center leading-tight line-clamp-2 max-w-[80px] ${filters.category === cat.name ? 'text-orange-500' : 'text-gray-600 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white'}`}>{cat.name}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

