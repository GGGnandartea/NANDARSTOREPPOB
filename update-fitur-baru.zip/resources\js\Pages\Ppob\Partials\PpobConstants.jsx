import React from 'react';

export const Icons = {
  Pulsa: ({ className = "w-6 h-6" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="5" y="2" width="14" height="20" rx="3" />
      <path d="M12 18h.01" />
      <path d="M9 5h6" />
      <path d="M17 7a3 3 0 0 1 3 3" />
      <path d="M17 4a6 6 0 0 1 6 6" />
    </svg>
  ),
  Pln: ({ className = "w-6 h-6" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.75V17h8v-2.25A7 7 0 0 0 12 2z" />
    </svg>
  ),
  Game: ({ className = "w-6 h-6" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="6" width="20" height="12" rx="6" />
      <line x1="6" y1="12" x2="10" y2="12" />
      <line x1="8" y1="10" x2="8" y2="14" />
      <circle cx="15.5" cy="12" r="1" fill="currentColor" />
      <circle cx="18.5" cy="12" r="1" fill="currentColor" />
    </svg>
  ),
  Ewallet: ({ className = "w-6 h-6" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="16" rx="3" />
      <path d="M2 10h20" />
      <circle cx="17" cy="14" r="1.5" fill="currentColor" />
    </svg>
  ),
  Streaming: ({ className = "w-6 h-6" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="20" height="14" rx="2" />
      <polygon points="10 8 16 11 10 14 10 8" fill="currentColor" stroke="none" />
      <line x1="8" y1="21" x2="16" y2="21" />
      <line x1="12" y1="17" x2="12" y2="21" />
    </svg>
  ),
  Tagihan: ({ className = "w-6 h-6" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" />
      <path d="M12 9v4" />
      <path d="M10 13h4" />
    </svg>
  ),
  Search: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  ),
  Lightning: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  ),
  Shield: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  ),
  CreditCard: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="16" rx="3" />
      <line x1="2" y1="10" x2="22" y2="10" />
    </svg>
  ),
  Clock: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  ),
  Check: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  ),
  X: ({ className = "w-4 h-4" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  ),
};

export const OPERATORS = [
  { id: '21', name: 'Telkomsel', code: 'telkomsel', prefixes: ['0811', '0812', '0813', '0821', '0822', '0823', '0851', '0852', '0853'] },
  { id: '11', name: 'Indosat Ooredoo', code: 'indosat', prefixes: ['0814', '0815', '0816', '0855', '0856', '0857', '0858'] },
  { id: '31', name: 'XL Axiata', code: 'xl', prefixes: ['0817', '0818', '0819', '0859', '0877', '0878'] },
  { id: '41', name: 'Tri (3)', code: 'tri', prefixes: ['0895', '0896', '0897', '0898', '0899'] },
  { id: '51', name: 'Axis', code: 'axis', prefixes: ['0831', '0832', '0833', '0838'] },
  { id: '81', name: 'Smartfren', code: 'smartfren', prefixes: ['0881', '0882', '0883', '0884', '0885', '0886', '0887', '0888', '0889'] },
  { id: 'byu', name: 'by.U', code: 'byu', prefixes: [] },
  { id: 'wifi', name: 'WiFi ID', code: 'wifi', prefixes: [] },
];

export const GAMES = [
  { id: 'AAO.AAAL', name: 'Mobile Legends', badge: 'MLBB', needZone: true, zoneLabel: 'Zone ID', placeholderId: 'Contoh: 12345678', placeholderZone: 'Contoh: 2149' },
  { id: 'AAO.AAAF', name: 'Free Fire', badge: 'FF', needZone: false, placeholderId: 'Contoh: 87654321' },
  { id: 'AAO.AAAJ', name: 'Honor of Kings', badge: 'HOK', needZone: false, placeholderId: 'Contoh: 98765432' },
  { id: 'AAO.AAAG', name: 'Genshin Impact', badge: 'GI', needZone: true, zoneLabel: 'Server', servers: ['Asia', 'America', 'Europe', 'TW_HK_MO'], placeholderId: 'UID Genshin' },
  { id: 'AAO.AAAS', name: 'PUBG Mobile', badge: 'PUBG', needZone: false, placeholderId: 'Nomor ID Karakter PUBG' },
  { id: 'AAO.AAAX', name: 'Valorant', badge: 'VAL', needZone: false, placeholderId: 'Riot ID (Nama#Tag)' },
  { id: 'AAO.AAAU', name: 'Roblox', badge: 'RBLX', needZone: false, placeholderId: 'Username Roblox' },
];

export const EWALLETS = [
  { id: 'EWAL.DANA', name: 'DANA', badge: 'DANA' },
  { id: 'EWAL.GOPAY', name: 'GoPay', badge: 'GOPAY' },
  { id: 'EWAL.OVO', name: 'OVO', badge: 'OVO' },
  { id: 'EWAL.SHOPEE', name: 'ShopeePay', badge: 'SPAY' },
];

export const STREAMING_SERVICES = [
  { id: 'AAB.AAAA', name: 'Spotify', badge: 'SPOTIFY', placeholder: 'Email / Username Spotify' },
  { id: 'AAB.AAAS', name: 'Netflix', badge: 'NETFLIX', placeholder: 'Email / Akun Netflix' },
  { id: 'AAB.AAAT', name: 'Disney+ Hotstar', badge: 'DISNEY+', placeholder: 'Nomor HP Akun Disney+' },
  { id: 'AAB.AAAE', name: 'Vidio', badge: 'VIDIO', placeholder: 'Nomor HP / Email Vidio' },
  { id: 'AAB.AAAW', name: 'Prime Video', badge: 'PRIME', placeholder: 'Email Akun Amazon Prime' },
  { id: 'AAB.AAAU', name: 'HBO GO', badge: 'HBO', placeholder: 'Email Akun HBO GO' },
  { id: 'AAB.AABA', name: 'Viu', badge: 'VIU', placeholder: 'Email / Akun Viu' },
  { id: 'AAB.AAAR', name: 'WeTV', badge: 'WETV', placeholder: 'Nomor HP / Akun WeTV' },
  { id: 'AAB.AAAP', name: 'Bstation', badge: 'BSTATION', placeholder: 'UID / Akun Bstation' },
  { id: 'AAB.AAAG', name: 'Vision+', badge: 'VISION+', placeholder: 'Nomor HP / Email Vision+' },
  { id: 'AAB.AAAC', name: 'Catchplay+', badge: 'CATCHPLAY', placeholder: 'Email Akun Catchplay' },
  { id: 'AAB.AAAB', name: 'beIN Sports', badge: 'BEIN', placeholder: 'Email beIN Sports Connect' },
  { id: 'AAB.AAAD', name: 'iTunes Gift Card', badge: 'ITUNES', placeholder: 'Apple ID / No HP' },
  { id: 'AAB.AAAQ', name: 'Tinder', badge: 'TINDER', placeholder: 'Nomor HP Akun Tinder' },
  { id: 'AAB.AAAJ', name: 'Bigo Live', badge: 'BIGO', placeholder: 'Bigo ID Pengguna' },
  { id: 'AAB.AAAY', name: 'JOOX Music', badge: 'JOOX', placeholder: 'Nomor HP / JOOX ID' },
  { id: 'AAB.AAAZ', name: 'iFlix', badge: 'IFLIX', placeholder: 'Email Akun iFlix' },
  { id: 'AAB.AAAX', name: 'Mola TV', badge: 'MOLA', placeholder: 'Email Akun Mola' },
  { id: 'AAB.AAAH', name: 'Genflix', badge: 'GENFLIX', placeholder: 'Email / Nomor HP Genflix' },
  { id: 'AAB.AAAI', name: 'Sushiroll', badge: 'SUSHIROLL', placeholder: 'Email Akun Sushiroll' },
  { id: 'AAB.AAAN', name: 'Lita', badge: 'LITA', placeholder: 'Lita User ID' },
  { id: 'AAB.AAAO', name: 'Litmatch', badge: 'LITMATCH', placeholder: 'Litmatch User ID' },
  { id: 'AAB.AAAK', name: 'Yalla Live', badge: 'YALLA', placeholder: 'Yalla Live ID' },
  { id: 'AAB.AAAL', name: 'Mico Live', badge: 'MICO', placeholder: 'Mico User ID' },
  { id: 'AAB.AAAM', name: 'LivU', badge: 'LIVU', placeholder: 'LivU User ID' },
  { id: 'AAB.AAAV', name: 'LinkPlus', badge: 'LINKPLUS', placeholder: 'Nomor HP / Akun LinkPlus' },
];

export const PPOB_TABS = [
  { id: 'pulsa', label: 'Pulsa & Data', iconKey: 'Pulsa', desc: 'Semua Operator' },
  { id: 'pln', label: 'PLN', iconKey: 'Pln', desc: 'Prabayar & Pascabayar' },
  { id: 'pdam', label: 'PDAM', iconKey: 'Tagihan', desc: 'Air Bersih' },
  { id: 'bpjs', label: 'BPJS', iconKey: 'Tagihan', desc: 'Kesehatan' },
  { id: 'game', label: 'Voucher Game', iconKey: 'Game', desc: 'MLBB, FF, Genshin' },
  { id: 'ewallet', label: 'E-Wallet', iconKey: 'Ewallet', desc: 'DANA, GoPay, OVO' },
  { id: 'streaming', label: 'Aplikasi Streaming', iconKey: 'Streaming', desc: 'Spotify, Netflix, Vidio' },
];

/** Tab yang memakai alur cek tagihan (inquiry) bukan katalog produk. */
export const BILL_TABS = ['pdam', 'pln_postpaid', 'bpjs'];


export const fmt = {
  rp: (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(n || 0),
};

