import React from 'react';
import { Link } from '@inertiajs/react';

export default function PpobMobileNav({ user }) {
  return (
    <div className="store-bottom-nav sm:hidden fixed bottom-0 left-0 right-0 z-[100] bg-white/95 dark:bg-[#0b1121]/95 backdrop-blur-xl border-t border-gray-200/90 dark:border-white/10 px-1 py-1 shadow-[0_-4px_20px_rgba(0,0,0,0.08)]">
      <div className="grid grid-cols-5 items-center">
        {/* 1. Beranda */}
        <Link href="/" className="flex flex-col items-center justify-center py-1 text-gray-500 dark:text-gray-400 hover:text-orange-500">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
            <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
          </svg>
          <span className="text-[8.5px] font-black mt-0.5 tracking-tight">Beranda</span>
        </Link>

        {/* 2. Aplikasi Premium */}
        <Link href="/#katalog-produk" className="flex flex-col items-center justify-center py-1 text-gray-500 dark:text-gray-400 hover:text-orange-500">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <rect x="3" y="3" width="7" height="7" rx="2" strokeWidth="2" />
            <rect x="14" y="3" width="7" height="7" rx="2" strokeWidth="2" />
            <rect x="14" y="14" width="7" height="7" rx="2" strokeWidth="2" />
            <rect x="3" y="14" width="7" height="7" rx="2" strokeWidth="2" />
          </svg>
          <span className="text-[8.5px] font-black mt-0.5 tracking-tight">Aplikasi</span>
        </Link>

        {/* 3. PPOB (ACTIVE) */}
        <div aria-current="page" className="flex flex-col items-center justify-center py-1 text-orange-500 dark:text-orange-400 relative">
          <div className="relative">
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="5" y="2" width="14" height="20" rx="3" />
              <path d="M12 18h.01" />
            </svg>
            <span className="absolute -top-1 -right-2 px-1 py-0.2 rounded-full bg-emerald-500 text-[6.5px] font-black text-white leading-none">
              HOT
            </span>
          </div>
          <span className="text-[8.5px] font-black mt-0.5 tracking-tight">PPOB</span>
        </div>

        {/* 4. Riwayat / Lacak */}
        <Link href="/profile?tab=orders" className="flex flex-col items-center justify-center py-1 text-gray-500 dark:text-gray-400 hover:text-orange-500">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/>
          </svg>
          <span className="text-[8.5px] font-black mt-0.5 tracking-tight">Riwayat</span>
        </Link>

        {/* 5. Profil */}
        <Link
          href={user ? (user.role === 'admin' ? '/admin/dashboard' : '/profile') : '/login'}
          className="flex flex-col items-center justify-center py-1 text-gray-500 dark:text-gray-400 hover:text-orange-500"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
          </svg>
          <span className="text-[8.5px] font-black mt-0.5 tracking-tight">{user ? 'Profil' : 'Masuk'}</span>
        </Link>
      </div>
    </div>
  );
}

